---
name: Sanad Human-Centric Assistive System
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#43474d'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#74777e'
  outline-variant: '#c3c6ce'
  surface-tint: '#49607c'
  primary: '#001428'
  on-primary: '#ffffff'
  primary-container: '#0f2942'
  on-primary-container: '#7991af'
  inverse-primary: '#b0c9e8'
  secondary: '#006a61'
  on-secondary: '#ffffff'
  secondary-container: '#86f2e4'
  on-secondary-container: '#006f66'
  tertiary: '#310001'
  on-tertiary: '#ffffff'
  tertiary-container: '#580004'
  on-tertiary-container: '#ff4f46'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d1e4ff'
  primary-fixed-dim: '#b0c9e8'
  on-primary-fixed: '#011d35'
  on-primary-fixed-variant: '#314863'
  secondary-fixed: '#89f5e7'
  secondary-fixed-dim: '#6bd8cb'
  on-secondary-fixed: '#00201d'
  on-secondary-fixed-variant: '#005049'
  tertiary-fixed: '#ffdad6'
  tertiary-fixed-dim: '#ffb4ab'
  on-tertiary-fixed: '#410002'
  on-tertiary-fixed-variant: '#93000b'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  headline-xl:
    fontFamily: IBM Plex Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: 0px
  headline-xl-mobile:
    fontFamily: IBM Plex Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: 0px
  headline-lg:
    fontFamily: IBM Plex Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 42px
    letterSpacing: 0px
  headline-lg-mobile:
    fontFamily: IBM Plex Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: 0px
  headline-md:
    fontFamily: IBM Plex Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: 0px
  body-xl:
    fontFamily: IBM Plex Sans
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 32px
    letterSpacing: 0px
  body-lg:
    fontFamily: IBM Plex Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 30px
    letterSpacing: 0px
  body-md:
    fontFamily: IBM Plex Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: 0px
  label-xl:
    fontFamily: IBM Plex Sans
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: 0px
  label-lg:
    fontFamily: IBM Plex Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: 0px
  label-md:
    fontFamily: IBM Plex Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1.25rem
  margin-mobile: 1rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1.25rem
  space-lg: 1.75rem
  space-xl: 2.5rem
---

## Brand & Style

The design system is engineered for assistive care, cognitive ease, and radical accessibility. Designed primarily for elderly users, visually impaired individuals, and people with physical or motor impairments, the design eliminates ambiguity, visual fatigue, and digital friction.

### Philosophy and Personality
- **Dignified & Reassuring:** Moves decisively away from clinical, sterile, or condescending disability aesthetics. It projects warmth, autonomy, respect, and steadfast reliability.
- **Cognitive Clarity:** Direct layouts, no multi-nested navigation drawers, no ambiguous gesture-only affordances, and zero unlabelled iconography. Every control is self-explanatory and immediate.
- **Radical Tactility:** Interfaces emphasize physical affordances—thick architectural borders, large tactile touch targets, and defined surface levels that communicate interactability instantly.

### Design Movement
- **Tactile High-Contrast Functionalism:** A fusion of high-contrast accessibility (WCAG AAA adherence) with soft, friendly organic surfaces. Elements feature distinct structural boundaries (2px crisp outlines), comforting rounded corners, and clear separation between canvas and actionable cards.

## Colors

The color palette prioritizes optical comfort, circadian calm, and absolute legibility. It meets or exceeds WCAG AAA contrast criteria (7:1 for normal text, 4.5:1 for large text and key graphics) across all states.

### Core Swatches
- **Primary Canvas Background (`#F8FAFC` to `#F1F5F9`):** A warm, tinted slate-cream foundation that reduces the glare and harsh optical halation often caused by pure white backgrounds on mobile OLED screens.
- **Primary Navy (`#0F2942`):** Grounded, authoritative, and deeply calming. Used for primary interactive actions, high-emphasis text, and core structural navigation containers.
- **Secondary Teal / Emerald (`#0D9488` / `#14B8A6`):** Evokes health, renewal, and calm verification. Used for active state indicators, completed health routines, success messaging, and supportive badges.
- **Emergency Crimson (`#DC2626` / `#EF4444`):** An unmistakable, urgent tone reserved solely for the dedicated SOS emergency trigger, critical medical warnings, and life-safety notifications.
- **Neutral High-Contrast Ink (`#0F172A`):** The primary reading ink, providing a 13:1+ contrast ratio against light foundations to ensure legibility for users with cataracts, low vision, or optical degeneration.
- **Surface Outline / Structural Border (`#CBD5E1` to `#0F2942`):** Explicit 2px structural lines separating interactive cards and containers from the page backdrop, eliminating ambiguity around clickable hit areas.

## Typography

The typography system relies on **IBM Plex Sans** (with full companion support for **IBM Plex Sans Arabic** in production), recognized for its open counters, distinct glyph differentiation, generous baseline stability, and high legibility across low-resolution and accessibility-scaled devices.

### Rules & Arabic RTL Typography Specs
- **Baseline Floor:** No text within the entire application may render smaller than `16px`. Auxiliary, helper, or legal micro-copy is strictly prohibited.
- **RTL Fluidity & Counter Openness:** IBM Plex Sans Arabic provides clarity for complex Arabic letterforms (such as differentiating *Seen*, *Sheen*, *Baa*, and *Noon* diacritics), mitigating optical crowding for seniors.
- **Line Heights:** Generous line-height ratios (minimum 1.5x - 1.6x body scale) prevent overlapping ascenders and descenders in Arabic Nastaliq/Kufic adaptations.
- **Weight Contrast:** Primarily relies on Medium (500), SemiBold (600), and Bold (700) weights. Ultra-thin, light, or hair-line font weights are strictly forbidden across all touchpoints.

## Layout & Spacing

The layout model is tailored to oversized mobile touch targets, one-handed grip postures, and assistive thumb-reach zones.

### Layout Philosophy
- **Single-Column Primacy:** Content flows in a linear, single-column vertical sequence on mobile devices. Multi-column cards and cluttered split grids are banned to avoid visual disorientation.
- **Touch-Boundary Isolation:** Every interactive item is isolated by generous vertical gaps (minimum `space-sm` = 12px; default `space-md` = 20px) to prevent misclicks caused by tremors or impaired hand dexterity.
- **Safe Viewports:** Margins protect elements from edge triggers, system swipe gesture collisions, and curved mobile screen boundaries.
- **Reachability (Thumb Zone):** High-priority interactive modules, emergency SOS triggers, and core flow controls are clustered in the bottom two-thirds of the viewport.

## Elevation & Depth

To preserve extreme clarity and avoid muddy interfaces for individuals with reduced contrast sensitivity or glaucoma, this design system does not use faint, fuzzy dropshadows.

### Affordance Through Structural Tiers
- **Tier 0 (Backdrop Canvas):** Soft, tinted cream/slate foundation (`#F8FAFC`). Flat, restful, non-distracting.
- **Tier 1 (Surface Cards & Trays):** Opaque pure white (`#FFFFFF`) interior surface surrounded by a definitive, crisp 2px solid border (`#CBD5E1`).
- **Tier 2 (Interactive Floating Controls & Action Sheets):** Framed in pure white with a pronounced tactile shadow: `0 8px 24px -4px rgba(15, 41, 66, 0.12), 0 2px 6px -1px rgba(15, 41, 66, 0.08)` and a 2px outer boundary (`#0F2942`).
- **Tier 3 (Emergency & High-Alert Modules):** Solid fill (`#DC2626` or `#0F2942`) accented with high-contrast outlines (2px solid white on dark, or 2px solid Navy on red) to ensure visual pop without relying on blur effects.

## Shapes

The design system incorporates roundedness tier `2` to balance soft, inviting approachability with crisp, unmistakable structural boundaries.

### Geometric Principles
- **Touch Elements:** Buttons, primary cards, and alert containers use 16px to 24px corner radii. This curvature guides gaze flow inward toward central labels while preserving the distinct identity of rectangular buttons.
- **Pill Shape Restriction:** Full pill-shapes (`rounded-full`) are reserved exclusively for contextual status indicators, state tags, and floating audio-readout buttons.
- **Stroke Architecture:** All card and actionable element perimeters maintain a uniform, unyielding 2px stroke width, reinforcing physical button-like presence across light and dark modes.

## Components

Every component adheres to RTL-first structural balance, dual-encoding (icon + text), and a minimum 64px physical target zone.

### 1. Oversized Action Buttons (Primary, Secondary, SOS)
- **Dimensions:** Minimum height of 64px; SOS and Primary Flow buttons scale to 76px–80px.
- **Visual Design:** Solid fill (`#0F2942` Primary, `#0D9488` Secondary, `#DC2626` SOS). High-contrast label in Bold (`18px`–`20px`) accompanied by a prominent 28px–32px visual icon.
- **Tactile Border:** 2px solid border around the button perimeter. On press, transitions to an inner inset state with an instant physical scale dampener (0.98) and high-contrast focus ring (4px `#14B8A6`).

### 2. Dual-Label Cards & List Selectors
- **Structure:** 100% full-width items with a minimum vertical height of 88px.
- **Content Flow (RTL):** Prominent leading visual icon (36px, enclosed in a high-contrast circular container) on the right side $\rightarrow$ Two lines of text (Title in `headline-md` + Descriptive subtitle in `body-md`) $\rightarrow$ Large chevron or explicit status tag on the far left.
- **States:** Selected cards trigger a 3px active border in `#0D9488` alongside an explicit checkmark symbol to reinforce state without relying solely on hue.

### 3. Checkboxes, Toggles & Radio Buttons
- **Touch Area:** Enclosed in a 64px interactive wrapper.
- **Indicator Size:** Physical toggle/box controls measure 32px $\times$ 32px (double standard mobile sizes).
- **Affordance:** Checkboxes feature a thick 3px white checkmark on `#0F2942` or `#0D9488` fill when active. Toggle switches include distinct internal symbols (I / O) to reinforce binary status for colorblind users.

### 4. High-Affordance Input Fields
- **Container:** Minimum 64px height, `#FFFFFF` fill with a persistent 2px `#64748B` border, transitioning to a 3px `#0F2942` border on focus.
- **Typography:** Placeholder text rendered at 18px with AAA contrast (`#475569`). Active typed text in 20px `#0F172A`.
- **Integrated Voice Input:** A permanent 48px microphone button anchored within the input field allows speech-to-text input on every text box.

### 5. Persistent Emergency SOS Component
- **Placement:** Anchored reliably at the bottom of the viewport or top navigation bar.
- **Styling:** Vivid `#DC2626` base, stark white bold Arabic text ("طوارئ / SOS"), accompanied by an unmistakable alarm/beacon icon. 
- **Safety Mechanism:** Requires an intentional 1.5-second tactile long-press with an active circular countdown border to prevent accidental triggers while guaranteeing immediate access during crises.

### 6. Voice Companion & Screen Reader Bar
- **Feature:** A dedicated audio control banner present on every informational screen.
- **Behavior:** Tapping triggers clear, measured speech synthesis of the on-screen content in standard Arabic, complemented by an active visual sentence highlighter.